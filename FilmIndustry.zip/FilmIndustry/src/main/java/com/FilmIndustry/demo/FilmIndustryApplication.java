package com.FilmIndustry.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmIndustryApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmIndustryApplication.class, args);
	}

}
