package com.requestparam.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequestparamApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequestparamApplication.class, args);
	}

}
