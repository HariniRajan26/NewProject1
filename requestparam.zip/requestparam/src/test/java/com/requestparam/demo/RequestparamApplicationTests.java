package com.requestparam.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestparamApplicationTests {

	@Test
	void contextLoads() {
	}

}
